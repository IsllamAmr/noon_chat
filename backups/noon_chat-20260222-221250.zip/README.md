# 📱 Noon Chat

A real-time chat application built with **Flutter & Firebase**.

## ✨ Features
- Google Sign-In Authentication
- Real-time messaging using Firestore
- Invite system with unique codes
- QR code sharing
- Delete chats from your inbox
- Clean chat UI with message bubbles

## 🛠 Tech Stack
- Flutter (Dart)
- Firebase Authentication
- Cloud Firestore
- Google Sign-In
- QR Flutter
- Share Plus

## 🚀 How to Run
```bash
flutter pub get
flutter run
## 📸 Screenshots

![Login Screen](assets/screenshots/login.png)
![Home Screen](assets/screenshots/home.png)
![Chat Screen](assets/screenshots/chat.png)
![Invite Screen](assets/screenshots/invite.png)
